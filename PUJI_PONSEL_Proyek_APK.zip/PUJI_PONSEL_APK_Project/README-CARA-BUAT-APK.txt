PUJI PONSEL - CARA MEMBUAT APK DARI HP ANDROID

Paket ini adalah proyek Android yang membungkus file HTML PUJI PONSEL ke dalam aplikasi WebView.
Fitur HTML asli dipertahankan. Data disimpan di penyimpanan lokal aplikasi (localStorage).

CARA PALING PRAKTIS DARI HP:
1. Ekstrak ZIP ini jika diperlukan, atau unggah ZIP ke GitHub sebagai repository baru.
2. Buka https://github.com melalui Chrome dan masuk/daftar akun.
3. Buat repository baru bernama puji-ponsel-apk.
4. Unggah seluruh ISI folder proyek ini (bukan file ZIP sebagai satu file) ke repository.
   Pastikan folder .github/workflows ikut terunggah. Jika tidak terlihat di pemilih file,
   aktifkan "Tampilkan file tersembunyi" atau unggah melalui GitHub versi desktop.
5. Setelah file terunggah, buka tab Actions pada repository.
6. Pilih "Build PUJI PONSEL APK", lalu tekan "Run workflow".
7. Tunggu sampai proses selesai dengan tanda centang hijau.
8. Buka hasil proses tersebut, cari bagian Artifacts, lalu unduh
   PUJI-PONSEL-APK.
9. Ekstrak ZIP hasil unduhan. Di dalamnya ada app-debug.apk.
10. Ketuk app-debug.apk untuk memasang. Jika Android meminta izin,
    izinkan Chrome atau aplikasi File memasang aplikasi dari sumber tersebut.

CATATAN:
- APK debug ini untuk pemasangan dan uji coba pribadi.
- APK ini belum ditandatangani sebagai rilis resmi/Play Store.
- Jangan hapus data aplikasi atau uninstall aplikasi jika ingin mempertahankan data
  pembukuan yang tersimpan di dalam aplikasi.
- Simpan cadangan data secara berkala. File HTML saat ini belum memiliki fitur ekspor
  atau pencadangan data.
- Build memerlukan akun GitHub dan koneksi internet.
