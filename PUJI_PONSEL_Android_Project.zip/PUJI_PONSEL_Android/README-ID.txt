PUJI PONSEL - Project Android

Project ini membungkus aplikasi HTML PUJI PONSEL ke dalam Android WebView.
JavaScript dan DOM storage diaktifkan agar fungsi aplikasi dan penyimpanan localStorage berjalan.

CARA MEMBUAT APK:
1. Instal Android Studio di komputer.
2. Ekstrak ZIP ini.
3. Buka Android Studio > Open > pilih folder PujiPonsel.
4. Tunggu Gradle Sync selesai. Jika diminta, instal Android SDK Platform 35 dan Build Tools.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK hasil build biasanya ada di app/build/outputs/apk/debug/app-debug.apk.
7. Kirim APK ke HP Android lalu instal. Jika diminta, izinkan instalasi dari sumber tersebut.

CATATAN:
- Ini adalah project sumber Android yang siap dibuka di Android Studio, bukan file APK yang sudah dikompilasi.
- Lingkungan pembuatan saat ini tidak menyediakan Android SDK/Gradle untuk menghasilkan APK biner secara langsung.
- Data aplikasi disimpan lokal di perangkat melalui localStorage. Hapus data aplikasi/uninstall dapat menghapus data tersebut; lakukan pencadangan sebelum reset perangkat.
